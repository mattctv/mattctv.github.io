#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
import xbmcvfs
import glob
import os
import sys
import time
import shutil
import fnmatch
from shutil import copytree
from shutil import copyfile
from shutil import rmtree
import sqlite3
from sqlite3 import dbapi2 as db_lib
from sqlite3 import OperationalError as OperationalError
from sqlite3 import DatabaseError as DatabaseError
from sqlite3 import dbapi2 as sqlite
import urllib
import urllib.request
import re
from zipfile import ZipFile
import ntpath
import xml.etree.cElementTree as ElementTree
from xml.dom import minidom
import pyxbmct

_addon = xbmcaddon.Addon()
_addon_path = _addon.getAddonInfo('path')

USER_AGENT = \
    'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36 ReplicantWizard/1.0.0'
dialog = xbmcgui.Dialog()
_addon = xbmcaddon.Addon()
_addon_path = _addon.getAddonInfo('path')
_background = xbmc.translatePath(os.path.join('special://home',
                                 'addons/script.mattctv.allinone',
                                 'fanart.jpg'))
home_folder = xbmc.translatePath(os.path.join('special://', 'home'))
package_folder = xbmc.translatePath(os.path.join('special://home/',
                                    'addons', 'packages'))
addons_folder = xbmc.translatePath(os.path.join('special://home/',
                                   'addons'))

if xbmc.getCondVisibility('System.Platform.Android'):
    _addon.setSetting('platform', 'Android')
elif xbmc.getCondVisibility('System.Platform.Windows'):
    _addon.setSetting('platform', 'Windows')
elif xbmc.getCondVisibility('System.Platform.Linux.RaspberryPi'):
    _addon.setSetting('platform', 'RaspberryPi')
else:
    _addon.setSetting('platform', 'Openelec')

os_platform = _addon.getSetting('platform')

busystring = xbmc.getLocalizedString(503).encode('utf8')
i = 1
mac_address = xbmc.getInfoLabel('Network.MacAddress')
while mac_address == busystring:
    xbmc.executebuiltin('ActivateWindow(busydialog)')
    print ('cekam: %s' % i)
    i = i + 1
    mac_address = xbmc.getInfoLabel('Network.MacAddress')
    time.sleep(1)
    if i == 20:
        break

xbmc.executebuiltin('Dialog.Close(busydialog)')

mac_address = mac_address[9:]
new_mac = '00:1A:79:' + mac_address
_addon.setSetting('mac', new_mac)


def ensure_dir(file_path):
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)


def extract(_in, _out, dp):

    zin = ZipFile(_in, 'r')

    nFiles = float(len(zin.infolist()))
    count = 0

    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, _out)
    except:
        return False

    return True


def download(url, dest, dp):
    dp.update(0)
    urllib.request.urlretrieve(url, dest, lambda nb, bs, fs, url=url: \
                       pbhook(nb, bs, fs, url, dp))


def pbhook(
    numblocks,
    blocksize,
    filesize,
    url,
    dp,
    ):
    try:
        percent = min(numblocks * blocksize * 100 / filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled():
        raise Exception('Canceled')
        dp.close()


def killxbmc():
    if xbmc.getCondVisibility('System.Platform.Windows'):
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except:
            pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except:
            pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except:
            pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except:
            pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]',
                  "If you\'re seeing this message, you ",
                  '[COLOR=yellow][B]MUST[/COLOR][/B] force close Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.'
                  ,
                  '[COLOR=red][B]UNPLUG THE POWER TO YOUR BOX!!![/COLOR][/B]'
                  )

    if xbmc.getCondVisibility('system.platform.android'):
        try:
            os.system('kill $(ps | busybox grep org.xbmc.kodi | busybox awk "{ print $2 }")'
                      )
        except:
            pass
        try:
            os.system('kill $(ps | busybox grep com.sempermax.spmc16 | busybox awk "{ print $2 }")'
                      )
        except:
            pass
        try:
            os.system('kill $(ps | busybox grep com.sempermax.spmc | busybox awk "{ print $2 }")'
                      )
        except:
            pass
        try:
            os.system('kill $(ps | busybox grep org.xbmc.kodi | busybox awk "{ print $2 }")'
                      )
        except:
            pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]',
                  "If you\'re seeing this message, you ",
                  '[COLOR=yellow][B]MUST[/COLOR][/B] force close Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.'
                  ,
                  '[COLOR=red][B]UNPLUG THE POWER TO YOUR BOX!!![/COLOR][/B]'
                  )

    if xbmc.getCondVisibility('system.platform.linux'):
        try:
            os.system('killall Kodi')
        except:
            pass
        try:
            os.system('killall SMC')
        except:
            pass
        try:
            os.system('killall XBMC')
        except:
            pass
        try:
            os.system('killall -9 xbmc.bin')
        except:
            pass
        try:
            os.system('killall -9 SMC.bin')
        except:
            pass
        try:
            os.system('killall -9 kodi.bin')
        except:
            pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]',
                  "If you\'re seeing this message, you ",
                  '[COLOR=yellow][B]MUST[/COLOR][/B] force close Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.'
                  ,
                  '[COLOR=red][B]UNPLUG THE POWER TO YOUR BOX!!![/COLOR][/B]'
                  )
    else:

        try:
            os.system('sudo initctl stop kodi')
        except:
            pass
        try:
            os.system('sudo initctl stop xbmc')
        except:
            pass
        try:
            os.system('sudo initctl stop tvmc')
        except:
            pass
        try:
            os.system('sudo initctl stop smc')
        except:
            pass
        dialog.ok('[COLOR=red][B]WARNING  !!![/COLOR][/B]',
                  "If you\'re seeing this message, you ",
                  '[COLOR=yellow][B]MUST[/COLOR][/B] force close Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.'
                  ,
                  '[COLOR=red][B]UNPLUG THE POWER TO YOUR BOX!!![/COLOR][/B]'
                  )


def handle_wait(time_to_wait, title, text):
    progressmessage = xbmcgui.DialogProgress()
    ret = progressmessage.create(' ' + title)
    secs = 0
    percent = 0
    increment = int(100 / time_to_wait)
    cancelled = False
    while secs < time_to_wait:
        secs += 1
        percent = increment * secs
        secs_left = str(time_to_wait - secs)
        remaining_display = str(secs_left) + ' seconds'
        progressmessage.update(percent, text, remaining_display)
        xbmc.sleep(1000)
        if progressmessage.iscanceled():
            cancelled = True
            break
    if cancelled == True:
        return False
    else:
        progressmessage.close()
        return False


def install_update():

    xbmc.executebuiltin('ActivateWindow(busydialog)')

    EXCLUDES = [
        'script.mattctv.allinone',
        'repository.mattctv',
        'script.module.pyxbmct',
        'script.module.future',
        'script.module.kodi-six',
        'script.module.resolveurl',
        'script.module.urlresolver',
        ]

    xbmcPath = os.path.join(_addon_path, '..', '..')
    xbmcPath = os.path.abspath(xbmcPath)

    try:
        for (root, dirs, files) in os.walk(xbmcPath, topdown=True):
            dirs[:] = [d for d in dirs if d not in EXCLUDES]
            for name in files:
                if name not in ['Addons27.db']:
                    try:
                        os.remove(os.path.join(root, name))
                    except:
                        pass
    except:
        pass

    for (root, dirs, files) in os.walk(xbmcPath, topdown=True):
        dirs[:] = [d for d in dirs if d not in EXCLUDES]
        for name in dirs:
            try:
                os.rmdir(os.path.join(root, name))
            except:
                pass

    _addon.setSetting('mode', 'Fresh_Start')
    _addon.setSetting('firstrun', 'Yes')
    handle_wait(5, 'Kodi Close',
                'System has been reset to Defaults. Kodi will close in:'
                )
    killxbmc()
    time.sleep(10)


class ActivateBuild(pyxbmct.AddonFullWindow):

    def __init__(self, title=''):
        super(ActivateBuild, self).__init__(title)
        self.setBackground(_background)
        self.setGeometry(1280, 720, 11, 5)
        self.set_wizard_info()
        self.set_wizard_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_wizard_info(self):

        #

        activated_label = pyxbmct.Label('Activated:',
                textColor='0xFFFFFF00', alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(activated_label, 2, 0)
        self.label = pyxbmct.Label(_addon.getSetting('activated'))
        self.placeControl(self.label, 2, 1)

        #

        mac_label = pyxbmct.Label('MAC:', textColor='0xFFFFFF00',
                                  alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(mac_label, 3, 0)
        self.label = pyxbmct.Label(_addon.getSetting('mac'))
        self.placeControl(self.label, 3, 1)

        #

        platform_label = pyxbmct.Label('Platform:',
                textColor='0xFFFFFF00', alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(platform_label, 4, 0)
        self.label = pyxbmct.Label(_addon.getSetting('platform'))
        self.placeControl(self.label, 4, 1)

        #

        mode_label = pyxbmct.Label('Wizard Mode:',
                                   textColor='0xFFFFFF00',
                                   alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(mode_label, 5, 0)
        self.label = pyxbmct.Label(_addon.getSetting('mode'))
        self.placeControl(self.label, 5, 1)

    def set_wizard_controls(self):

        login_label = pyxbmct.Label('Login:', textColor='0xFFFFFF00',
                                    alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(login_label, 1, 3, 1, 1)

        user_label = pyxbmct.Label('Username:', textColor='0xFFFFFF00',
                                   alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(user_label, 2, 2)
        self.user = pyxbmct.Edit('', _alignment=2 | 4)
        self.placeControl(self.user, 2, 3)

        pwd_label = pyxbmct.Label('Password:', textColor='0xFFFFFF00',
                                  alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(pwd_label, 3, 2)
        self.pwd = pyxbmct.Edit('', isPassword=True, _alignment=2 | 4)
        self.placeControl(self.pwd, 3, 3)

        self.run_button = pyxbmct.Button('Run Wizard')
        self.placeControl(self.run_button, 4, 3)
        self.connect(self.run_button, self.update_creds)

    def set_navigation(self):

        self.user.controlUp(self.run_button)
        self.user.controlDown(self.pwd)

        self.pwd.controlUp(self.user)
        self.pwd.controlDown(self.run_button)

        self.run_button.controlUp(self.pwd)
        self.run_button.controlDown(self.user)

        self.setFocus(self.user)

    def update_creds(self):
        username = self.user.getText()
        password = self.pwd.getText()
        _addon.setSetting('user', username)
        _addon.setSetting('pass', password)
        self.activate()

    def activate(self):

        sendpwd = _addon.getSetting('pass')
        senduser = _addon.getSetting('user')
        sendmac = _addon.getSetting('mac')

        check_url = 'http://repo.mattctv.net/register/check.php?name=' \
            + senduser + '&pass=' + sendpwd + '&mac=' + sendmac \
            + '&wiz=activate'

        link = urllib.request.urlopen(check_url)
        total = link.read()
        build = total
        build = build[50] + build[51] + build[52] + build[53] \
            + build[54]

        if '688' in total:
            dialog.ok('Activation Successful',
                      'Click OK to install the MATTCTV Build',
                      'When the Build Completes Kodi will Restart')
            _addon.setSetting('activated', 'Yes')
            _addon.setSetting('build', build)
            self.install_build()
        else:

            dialog.ok('Incorrect Login or No Activations Available for this User'
                      ,
                      'Please signin here: http://repo.mattctv.net/register/login'
                      )
            _addon.setSetting('mode', 'Fresh_Start')
            sys.exit()

    def install_build(self):

        build_zip = '7.0.0.zip'
        zip_url = 'http://repo.mattctv.net/zips/master/builds/7.0.0.zip'

        path = package_folder + '/' + build_zip

        dp = xbmcgui.DialogProgress()
        dp.create('Downloading Files....', 'Please Wait....')

        download(zip_url, path, dp)
        time.sleep(2)
        dp.update(0, 'Getting Things Ready....')
        extract(path, home_folder, dp)

        dp.update(0, 'Updating Addons....')
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('UpdateLocalAddons')
        time.sleep(60)

        _addon.setSetting('mode', 'Updates')

        time.sleep(2)
        dialog.ok('Build Installed', 'Kodi must close')
        time.sleep(2)

        killxbmc()
        time.sleep(10)


class Updates(pyxbmct.AddonFullWindow):

    def __init__(self, title=''):
        super(Updates, self).__init__(title)
        self.setBackground(_background)
        self.setGeometry(1280, 720, 11, 5)
        self.set_wizard_info()
        self.set_wizard_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_wizard_info(self):

        #

        activated_label = pyxbmct.Label('Activated:',
                textColor='0xFFFFFF00', alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(activated_label, 2, 0)
        self.label = pyxbmct.Label(_addon.getSetting('activated'))
        self.placeControl(self.label, 2, 1)

        #

        mac_label = pyxbmct.Label('MAC:', textColor='0xFFFFFF00',
                                  alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(mac_label, 3, 0)
        self.label = pyxbmct.Label(_addon.getSetting('mac'))
        self.placeControl(self.label, 3, 1)

        #

        platform_label = pyxbmct.Label('Platform:',
                textColor='0xFFFFFF00', alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(platform_label, 4, 0)
        self.label = pyxbmct.Label(_addon.getSetting('platform'))
        self.placeControl(self.label, 4, 1)

        #

        mode_label = pyxbmct.Label('Wizard Mode:',
                                   textColor='0xFFFFFF00',
                                   alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(mode_label, 5, 0)
        self.label = pyxbmct.Label(_addon.getSetting('mode'))
        self.placeControl(self.label, 5, 1)

        #

        build_label = pyxbmct.Label('Build Version:',
                                    textColor='0xFFFFFF00',
                                    alignment=pyxbmct.ALIGN_RIGHT)
        self.placeControl(build_label, 6, 0)
        self.label = pyxbmct.Label(_addon.getSetting('build'))
        self.placeControl(self.label, 6, 1)

    def set_wizard_controls(self):

        self.update_button = pyxbmct.Button('Check for Updates')
        self.placeControl(self.update_button, 3, 3)
        self.connect(self.update_button, self.update_check)

        self.reinstall_button = pyxbmct.Button('Reinstall Build')
        self.placeControl(self.reinstall_button, 4, 3)
        self.connect(self.reinstall_button, self.reinstall_build)

    def set_navigation(self):

        self.setFocus(self.update_button)

        # From Update

        self.update_button.controlUp(self.reinstall_button)
        self.update_button.controlDown(self.reinstall_button)

        # From Reinstall

        self.reinstall_button.controlUp(self.update_button)
        self.reinstall_button.controlDown(self.update_button)

    def update_check(self):

        sendpwd = _addon.getSetting('pass')
        senduser = _addon.getSetting('user')
        sendmac = _addon.getSetting('mac')

        check_url = 'http://repo.mattctv.net/register/check.php?name=' \
            + senduser + '&pass=' + sendpwd + '&mac=' + sendmac \
            + '&wiz=updates'
        link = urllib.request.urlopen(check_url)
        total = link.read()
        new_build = total
        new_build = new_build[50] + new_build[51] + new_build[52] \
            + new_build[53] + new_build[54]

        current_build = _addon.getSetting('build')

        if new_build != current_build:
            yesno_pass = 0
            while yesno_pass == 0:
                choice = dialog.yesno('Build Update Available',
                        'A newer version of the MattCTV Build is available'
                        , 'Would you like to update from: '
                        + current_build + ' to: ' + new_build + ' ?')
                if choice == 1:
                    yesno_pass = 1
                    self.reinstall_build()
                else:
                    yesno_pass = 1
        else:
            dialog.ok('No New Updates',
                      'The latest version of the MattCTV Build is already installed')

    def reinstall_build(self):
        yes_pressed = dialog.yesno('Reinstall Build', 'This will restore your MattCTV config and install the newest build')
        if yes_pressed:

            EXCLUDES = [
                'script.mattctv.allinone',
                'repository.mattctv',
                'script.module.pyxbmct',
                'script.module.future',
                'script.module.kodi-six',
                'script.module.resolveurl',
                'script.module.urlresolver',
                ]

            xbmcPath = os.path.join(_addon_path, '..', '..')
            xbmcPath = os.path.abspath(xbmcPath)

            try:
                for (root, dirs, files) in os.walk(xbmcPath,
                        topdown=True):
                    dirs[:] = [d for d in dirs if d not in EXCLUDES]
                    for name in files:
                        if name not in ['Addons27.db']:
                            try:
                                os.remove(os.path.join(root, name))
                            except:
                                pass
            except:
                pass

            for (root, dirs, files) in os.walk(xbmcPath, topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in dirs:
                    try:
                        os.rmdir(os.path.join(root, name))
                    except:
                        pass

            _addon.setSetting('mode', 'Fresh_Start')
            _addon.setSetting('firstrun', 'Yes')
            handle_wait(5, 'Kodi Close',
                        'System has been reset to Defaults. Kodi will close in:'
                        )
            killxbmc()
            time.sleep(10)


if _addon.getSetting('mode') == 'First_Run':
    dialog.ok('Wizard Installed',
              'Kodi must close')
    
    time.sleep(2)
    _addon.setSetting('mode', 'Fresh_Start')
    time.sleep(2)
    reboot = 0
    while reboot == 0:
        if os_platform == 'Openelec':
            xbmc.executebuiltin('RestartApp')
            time.sleep(10)
        elif os_platform == 'RaspberryPi':
            xbmc.executebuiltin('RestartApp')
            time.sleep(10)
        else:
            killxbmc()
            time.sleep(10)

if _addon.getSetting('mode') == 'Fresh_Start':

    sendmac = _addon.getSetting('mac')
    check_url = 'http://repo.mattctv.net/register/check.php?mac=' \
        + sendmac + '&wiz=fresh'
    link = urllib.request.urlopen(check_url)
    total = link.read()
    build = total
    build = build[50] + build[51] + build[52] + build[53] + build[54]
    total_as_string = str(total)
    
    if '424' in total_as_string:

        _addon.setSetting('activated', 'Yes')
        _addon.setSetting('build', 'build')

        build_zip = '7.0.0.zip'
        zip_url = 'http://repo.mattctv.net/zips/master/builds/7.0.0.zip'

        path = package_folder + '/' + build_zip

        dp = xbmcgui.DialogProgress()
        dp.create('Downloading Files....', 'Please Wait....')

        download(zip_url, path, dp)
        time.sleep(2)
        dp.update(0, 'Getting Things Ready....')
        extract(path, home_folder, dp)

        _addon.setSetting('mode', 'Updates')

        time.sleep(2)
        dialog.ok('Build Installed', 'Kodi must close')
        time.sleep(2)

        killxbmc()
    else:

        _addon.setSetting('mode', 'Activate')
        xbmc.executebuiltin('RunScript(script.mattctv.allinone)')

if _addon.getSetting('mode') == 'Activate':

    window = ActivateBuild('MattCTV All-in-One Wizard')
    window.doModal()
    del window

if _addon.getSetting('mode') == 'Updates':

    window = Updates('MattCTV All-in-One Wizard')
    window.doModal()
    del window
