import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import os
import sys
import time
import shutil
from shutil import copytree
from shutil import rmtree
import sqlite3
from sqlite3 import dbapi2 as db_lib
from sqlite3 import OperationalError as OperationalError
from sqlite3 import DatabaseError as DatabaseError
from shutil import copyfile
import urllib
import re
import zipfile
import ntpath

time.sleep(15)

dialog = xbmcgui.Dialog()
_addon = xbmcaddon.Addon('script.mattctv.allinone')
mode = _addon.getSetting('mode')

def handle_wait(time_to_wait,title,text):
    progressmessage = xbmcgui.DialogProgress()
    ret = progressmessage.create(' '+title)
    secs=0
    percent=0
    increment = int(100 / time_to_wait)
    cancelled = False
    while secs < time_to_wait:
        secs += 1
        percent = increment*secs
        secs_left = str((time_to_wait - secs))
        remaining_display = str(secs_left) + " seconds"
        progressmessage.update(percent,text,remaining_display)
        xbmc.sleep(1000)
        if (progressmessage.iscanceled()):
            cancelled = True
            break
    if cancelled == True:
        return False
    else:
        progressmessage.close()
        return False

if mode == 'First_Run':
	xbmc.executebuiltin('RunScript(script.mattctv.allinone)')
	
elif mode == 'Fresh_Start':
	xbmc.executebuiltin('RunScript(script.mattctv.allinone)')
	
elif mode == 'Activate':
	xbmc.executebuiltin('RunScript(script.mattctv.allinone)')
	
elif mode == 'Updates':
	
	if _addon.getSetting('firstrun') == 'Yes':
		
		purgePath = xbmc.translatePath('special://home/addons/packages')
		file_count = 0
		for root, dirs, files in os.walk(purgePath):
			file_count += len(files)
		if file_count > 0:
				for root, dirs, files in os.walk(purgePath):
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						rmtree(os.path.join(root, d))
		time.sleep(25)
			
		if _addon.getSetting('platform') == 'Openelec':
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"locale.timezone","value":"America/Edmonton"}}')
			dialog.ok("MATTCTV Config - SOUND", "If your sound is not working:", "\nGo to MattCTV > System > System > Audio output > Audio output device - Set it to your HDMI port")
			
		if _addon.getSetting('platform') == 'RaspberryPi':
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "id":1, "method":"Settings.SetSettingValue","params":{"setting":"locale.timezone","value":"America/Edmonton"}}')
			dialog.ok("MATTCTV Config - SOUND", "If your sound is not working:", "\nGo to MattCTV > System > System > Audio output > Audio output device - Set it to your HDMI port")
			
		_addon.setSetting('firstrun', 'No')
		
	else:
		pass
		
	xbmc.executebuiltin('UpdateAddonRepos')
	xbmc.executebuiltin('UpdateLocalAddons')

elif mode == 'Stalker_Config':
			
	mac = _addon.getSetting('mac')
	user = _addon.getSetting('user')
	server = 'cod123.biz:88/stalker_portal/c/'
	timezone = 'America/Edmonton'
	
	pvr_addon = xbmcaddon.Addon('pvr.stalker')
	pvr_addon.setSetting('mac_0', mac)
	pvr_addon.setSetting('login_0', user)
	pvr_addon.setSetting('password_0', user)
	pvr_addon.setSetting('connection_timeout', '3')
	pvr_addon.setSetting('server_0', server)
	pvr_addon.setSetting('time_zone_0', timezone)
	pvr_addon.setSetting('xmltv_url_0', server)
	
	_addon.setSetting('livetv', 'Yes')
	_addon.setSetting('mode', 'Updates')
	
	time.sleep(5)
	
	handle_wait(5,'MATTCTV Config - LIVE TV','Setup is Complete. Kodi will close in:')
	reboot = 0
	while reboot ==0:
		if _addon.getSetting('platform') == 'Openelec':
			xbmc.executebuiltin('RestartApp')
			time.sleep(10)
		elif _addon.getSetting('platform') == 'RaspberryPi':
			xbmc.executebuiltin('RestartApp')
			time.sleep(10)
		else:
			xbmc.executebuiltin('Quit')
			time.sleep(10)

else:
	sys.exit()